param(
    [string]$MsiPath = "C:\Users\Public\installer.msi",
    [int]$MaxAttempts = 30,
    [switch]$Hidden
)

$marker = "C:\Users\Public\install_done.log"

function IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ---------------------------------------------------------------
# Самоперезапуск в скрытом режиме (выполняется один раз)
# ---------------------------------------------------------------
if (-not $Hidden) {
    $argsLine = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-WindowStyle", "Hidden",
        "-File", "`"$PSCommandPath`"",
        "-MsiPath", "`"$MsiPath`"",
        "-MaxAttempts", $MaxAttempts,
        "-Hidden"
    ) -join " "

    Start-Process powershell.exe -ArgumentList $argsLine -WindowStyle Hidden
    exit
}

# ---------------------------------------------------------------
# Админ-ветка: тихо ставим MSI и пишем маркер
# ---------------------------------------------------------------
if (IsAdmin) {
    "admin" | Out-File $marker -Encoding utf8 -Append

    Start-Process msiexec.exe `
        -ArgumentList "/i `"$MsiPath`" /quiet /norestart" `
        -Wait -WindowStyle Hidden

    "0" | Out-File $marker -Encoding utf8 -Append
    exit 0
}

# ---------------------------------------------------------------
# Пользовательская ветка: запрашиваем UAC, ждём маркер
# ---------------------------------------------------------------
Remove-Item $marker -ErrorAction SilentlyContinue

for ($i = 1; $i -le $MaxAttempts; $i++) {
    try {
        Start-Process powershell.exe `
            -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`" -MsiPath `"$MsiPath`" -MaxAttempts $MaxAttempts -Hidden" `
            -Verb RunAs -Wait -WindowStyle Hidden
    }
    catch {
        Start-Sleep 2
        continue
    }

    if (Test-Path $marker) { exit 0 }
}

exit 3