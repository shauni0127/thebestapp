<#
====================================================================
 RMM-Shield.ps1 - COMPLETE SIMPLEHELP + JW RAPPER REMOVAL
--------------------------------------------------------------------
 FIXED: Full detection of SimpleHelp MSI + JWrapper-Remote Access
 ADDED: -Remove switch for self-removal
 ADDED: AGTA Backup Agent MSI removal
====================================================================
#>

[CmdletBinding()]
param(
    [ValidateSet('Audit','Enforce')]
    [string]$Mode = 'Audit',

    [string]$KeepSCThumbprint = '',
    [string[]]$KeepRMM = @(),
    [switch]$InstallWatchdog,
    [switch]$RemoveWatchdog,
    [switch]$Remove,  # NEW: Self-removal switch
    [int]$WatchdogIntervalMinutes = 15,
    [string]$LogPath = 'C:\ProgramData\RMM-Shield\rmm-shield.log',
    [switch]$ScorchedEarth
)

# --------------------------------------------------------------------
# RMM DETECTION RULES - ENHANCED
# --------------------------------------------------------------------
$RMMDetectionRules = @(
    # SimpleHelp - COMPLETE
    @{ 
        Name = 'SimpleHelp'
        Services = @('SimpleHelp', 'SimpleHelpService', 'SHService', 'SimpleHelpAgent', 'SHAgent')
        Processes = @('SimpleHelp', 'SimpleHelpService', 'SHService', 'SimpleHelpAgent', 'SHAgent', 'javaw', 'java')
        Folders = @('SimpleHelp')
        Registry = @('SimpleHelp', 'JWrapper-Remote Access', 'JWrapper')
        ExtraPaths = @(
            'C:\ProgramData\SimpleHelp',
            'C:\Program Files\SimpleHelp',
            'C:\Program Files (x86)\SimpleHelp',
            'C:\ProgramData\JWrapper-Remote Access',
            'C:\Users\*\AppData\Local\JWrapper-Remote Access',
            'C:\Users\*\AppData\Roaming\JWrapper-Remote Access'
        )
        MSIName = @('SimpleHelp', 'JWrapper-Remote Access')
    },
    
    # AGTA Backup Agent - NEW
    @{ 
        Name = 'AGTABackup'
        Services = @('AGTABackup*', 'AGTA*Backup*', 'AGTA*Agent*')
        Processes = @('AGTABackup*', 'AGTA*Backup*', 'AGTA*Agent*')
        Folders = @('AGTA Backup', 'AGTA Backup Agent', 'AGTABackup')
        Registry = @('AGTA Backup', 'AGTABackup', 'AGTA Backup Agent')
        MSIName = @('AGTA Backup', 'AGTABackup', 'AGTA Backup Agent')
        ExtraPaths = @(
            'C:\Program Files\AGTA Backup',
            'C:\Program Files (x86)\AGTA Backup',
            'C:\Program Files\AGTA Backup Agent',
            'C:\Program Files (x86)\AGTA Backup Agent',
            'C:\ProgramData\AGTA Backup',
            'C:\ProgramData\AGTABackup'
        )
    },
    
    # Other RMM
    @{ Name = 'AnyDesk';       Services = @('AnyDesk'); Processes = @('AnyDesk'); Folders = @('AnyDesk'); Registry = @('AnyDesk') },
    @{ Name = 'TeamViewer';    Services = @('TeamViewer*'); Processes = @('TeamViewer*'); Folders = @('TeamViewer'); Registry = @('TeamViewer') },
    @{ Name = 'Splashtop';     Services = @('Splashtop*'); Processes = @('Splashtop*'); Folders = @('Splashtop'); Registry = @('Splashtop') },
    @{ Name = 'LogMeIn';       Services = @('LogMeIn*'); Processes = @('LogMeIn*'); Folders = @('LogMeIn'); Registry = @('LogMeIn') },
    @{ Name = 'GoToAssist';    Services = @('GoToAssist*'); Processes = @('GoToAssist*'); Folders = @('GoToAssist'); Registry = @('GoToAssist') },
    @{ Name = 'RemotePC';      Services = @('RemotePC*'); Processes = @('RemotePC*'); Folders = @('RemotePC'); Registry = @('RemotePC') },
    @{ Name = 'Zoho Assist';   Services = @('ZohoAssist*'); Processes = @('ZohoAssist*'); Folders = @('Zoho Assist'); Registry = @('ZohoAssist') },
    @{ Name = 'NinjaRMM';      Services = @('NinjaRMM*','Ninja*'); Processes = @('NinjaRMM*','Ninja*'); Folders = @('NinjaRMM','Ninja'); Registry = @('NinjaRMM') },
    @{ Name = 'ConnectWise';   Services = @('ConnectWise*'); Processes = @('ConnectWise*'); Folders = @('ConnectWise'); Registry = @('ConnectWise') },
    @{ Name = 'Kaseya';        Services = @('Kaseya*','K*Agent'); Processes = @('Kaseya*','K*Agent'); Folders = @('Kaseya'); Registry = @('Kaseya') },
    @{ Name = 'DattoRMM';      Services = @('DattoRMM*','Datto*'); Processes = @('DattoRMM*','Datto*'); Folders = @('DattoRMM','Datto'); Registry = @('DattoRMM') },
    @{ Name = 'N-Able';        Services = @('N-Able*','Nable*'); Processes = @('N-Able*','Nable*'); Folders = @('N-Able','Nable'); Registry = @('N-Able') },
    @{ Name = 'SolarWinds';    Services = @('SolarWinds*','SW*Agent'); Processes = @('SolarWinds*','SW*Agent'); Folders = @('SolarWinds'); Registry = @('SolarWinds') },
    @{ Name = 'Atera';         Services = @('Atera*'); Processes = @('Atera*'); Folders = @('Atera'); Registry = @('Atera') },
    @{ Name = 'Pulseway';      Services = @('Pulseway*'); Processes = @('Pulseway*'); Folders = @('Pulseway'); Registry = @('Pulseway') },
    @{ Name = 'ManageEngine';  Services = @('ManageEngine*','ME*Agent'); Processes = @('ManageEngine*','ME*Agent'); Folders = @('ManageEngine'); Registry = @('ManageEngine') }
)

# --------------------------------------------------------------------
# Setup
# --------------------------------------------------------------------
$ErrorActionPreference = 'Continue'
$script:TaskName = 'RMM-Shield-Watchdog'
$script:RebootRecommended = $false
$script:ScriptRoot = 'C:\ProgramData\RMM-Shield'

New-Item -ItemType Directory -Force -Path (Split-Path $LogPath) | Out-Null

function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ACTION','ERROR')][string]$Level = 'INFO')
    $line = ('{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message)
    $color = switch ($Level) { 'WARN' {'Yellow'} 'ACTION' {'Cyan'} 'ERROR' {'Red'} default {'Gray'} }
    Write-Host $line -ForegroundColor $color
    try { Add-Content -Path $LogPath -Value $line -Encoding UTF8 } catch {}
}

function Assert-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Log 'Must be run from an ELEVATED PowerShell (Run as Administrator).' 'ERROR'
        exit 1
    }
}

function Normalize-Thumbprint([string]$t) {
    if (-not $t) { return $null }
    $t = ($t -replace '[^0-9a-fA-F]', '').ToLower()
    if ($t.Length -ge 12) { return $t }
    return $null
}

# --------------------------------------------------------------------
# SELF-REMOVAL FUNCTION - NEW
# --------------------------------------------------------------------
function Remove-Self {
    Write-Log '=== STARTING SELF-REMOVAL ===' 'ACTION'
    
    # 1. Remove watchdog task
    try {
        Unregister-ScheduledTask -TaskName $script:TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Write-Log 'Removed watchdog task.' 'ACTION'
    } catch {}
    
    # 2. Delete script directory
    $scriptPath = $script:ScriptRoot
    if (Test-Path $scriptPath) {
        Write-Log "Deleting script directory: $scriptPath" 'ACTION'
        try {
            takeown /f "$scriptPath" /r /d y 2>$null | Out-Null
            icacls "$scriptPath" /grant SYSTEM:F /t /q 2>$null | Out-Null
            Remove-Item -Path $scriptPath -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log 'Script directory deleted.' 'ACTION'
        } catch {
            Write-Log "Failed to delete directory: $($_.Exception.Message)" 'WARN'
        }
    }
    
    # 3. Delete log file
    if (Test-Path $LogPath) {
        Write-Log "Deleting log file: $LogPath" 'ACTION'
        try {
            Remove-Item -Path $LogPath -Force -ErrorAction SilentlyContinue
        } catch {}
    }
    
    # 4. Remove script from startup (if any)
    $startupPaths = @(
        "$env:PROGRAMDATA\Microsoft\Windows\Start Menu\Programs\StartUp\RMM-Shield.ps1",
        "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\RMM-Shield.ps1"
    )
    foreach ($path in $startupPaths) {
        if (Test-Path $path) {
            Write-Log "Removing startup entry: $path" 'ACTION'
            try { Remove-Item -Path $path -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
    
    # 5. Clean up scheduled tasks with similar names
    Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like '*RMM-Shield*' } | ForEach-Object {
        Write-Log "Removing scheduled task: $($_.TaskName)" 'ACTION'
        try { Unregister-ScheduledTask -TaskName $_.TaskName -Confirm:$false -ErrorAction SilentlyContinue } catch {}
    }
    
    Write-Log '=== SELF-REMOVAL COMPLETE ===' 'ACTION'
    Write-Log 'Script and all components have been removed.'
    Write-Log 'You may close this window.'
    
    # Self-delete the script file after a short delay
    $scriptFile = $MyInvocation.MyCommand.Path
    if (Test-Path $scriptFile) {
        Write-Log "Self-deleting script: $scriptFile" 'ACTION'
        # Use a background process to delete the script file
        Start-Process -WindowStyle Hidden -FilePath 'powershell.exe' -ArgumentList @(
            "-NoProfile -ExecutionPolicy Bypass -Command `"Start-Sleep -Seconds 3; Remove-Item -Path '$scriptFile' -Force -ErrorAction SilentlyContinue`""
        )
    }
    
    exit 0
}

# --------------------------------------------------------------------
# Discovery - COMPLETE
# --------------------------------------------------------------------
function Get-RMMInstances {
    $found = @{}
    $keepSCThumb = Normalize-Thumbprint $KeepSCThumbprint

    function Add-Hit($id, $name, $source, $detail, $servicename, $path, $process) {
        if (-not $id) { $id = "unknown-$source-$([guid]::NewGuid().ToString('N').Substring(0,6))" }
        if (-not $found.ContainsKey($id)) {
            $found[$id] = [pscustomobject]@{
                ID          = $id
                Name        = $name
                Services    = New-Object System.Collections.Generic.List[string]
                Paths       = New-Object System.Collections.Generic.List[string]
                Processes   = New-Object System.Collections.Generic.List[string]
                RegKeys     = New-Object System.Collections.Generic.List[string]
                Sources     = New-Object System.Collections.Generic.List[string]
                IsSC        = $false
                SCThumb     = $null
                PackageName = $null
                MSIProduct  = $null
            }
        }
        if ($servicename -and -not $found[$id].Services.Contains($servicename)) { $found[$id].Services.Add($servicename) }
        if ($path -and (Test-Path $path) -and -not $found[$id].Paths.Contains($path)) { $found[$id].Paths.Add($path) }
        if ($process -and -not $found[$id].Processes.Contains($process)) { $found[$id].Processes.Add($process) }
        if ($detail -and $detail -like 'HK*' -and -not $found[$id].RegKeys.Contains($detail)) { $found[$id].RegKeys.Add($detail) }
        if (-not $found[$id].Sources.Contains($source)) { $found[$id].Sources.Add($source) }
        
        if ($name -eq 'ScreenConnect' -or $servicename -match 'ScreenConnect|connectwisecontrol') {
            $found[$id].IsSC = $true
            if ($servicename -match '([0-9a-fA-F]{12,})') { 
                $found[$id].SCThumb = $Matches[1].ToLower()
                $found[$id].PackageName = "ScreenConnect Client ($($Matches[1]))"
            }
            elseif ($id -match '([0-9a-fA-F]{12,})') { 
                $found[$id].SCThumb = $Matches[1].ToLower()
                $found[$id].PackageName = "ScreenConnect Client ($($Matches[1]))"
            }
        }
    }

    # --- 1) Services ---
    Write-Log "Scanning services for RMM..." 'INFO'
    Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | ForEach-Object {
        $svcName = $_.Name
        $displayName = $_.DisplayName
        $pathName = $_.PathName
        
        # Skip Windows system services
        if ($svcName -match '^dmwappushservice|^WpnService|^BITS|^TrustedInstaller|^wuauserv|^Dnscache|^Dhcp|^EventLog') {
            return
        }
        
        # ScreenConnect
        if ($svcName -match 'ScreenConnect|connectwisecontrol' -or $displayName -match 'ScreenConnect|ConnectWise Control') {
            $thumb = $null
            if ($svcName -match '([0-9a-fA-F]{12,})') { $thumb = $Matches[1].ToLower() }
            elseif ($pathName -match '([0-9a-fA-F]{12,})') { $thumb = $Matches[1].ToLower() }
            $id = "ScreenConnect"
            if ($thumb) { $id += "-$thumb" }
            Add-Hit $id 'ScreenConnect' 'Service' $svcName $svcName (Split-Path $pathName) $null
            return
        }
        
        # SimpleHelp - Check service name, display, path
        $isSimpleHelp = $false
        if ($svcName -match '^(SimpleHelp|SimpleHelpService|SHService|SimpleHelpAgent|SHAgent|JWrapper|JWrapperService)$') {
            $isSimpleHelp = $true
            Write-Log "Found SimpleHelp/JWrapper service: $svcName" 'INFO'
        }
        if ($displayName -match '^(SimpleHelp|JWrapper)') {
            $isSimpleHelp = $true
            Write-Log "Found SimpleHelp/JWrapper service by display name: $displayName" 'INFO'
        }
        if ($pathName -and $pathName -match '(SimpleHelp|JWrapper)' -and $pathName -notmatch 'C:\\Windows\\System32') {
            $isSimpleHelp = $true
            Write-Log "Found SimpleHelp/JWrapper service by path: $pathName" 'INFO'
        }
        
        if ($isSimpleHelp) {
            $id = "SimpleHelp"
            Add-Hit $id 'SimpleHelp' 'Service' $svcName $svcName (Split-Path $pathName) $null
            return
        }
        
        # AGTA Backup Agent - NEW
        $isAGTA = $false
        if ($svcName -match '^(AGTABackup|AGTA.*Backup|AGTA.*Agent)$' -or $displayName -match 'AGTA Backup|AGTABackup|AGTA Agent') {
            $isAGTA = $true
            Write-Log "Found AGTA Backup service: $svcName" 'INFO'
        }
        if ($pathName -and $pathName -match 'AGTA Backup|AGTABackup' -and $pathName -notmatch 'C:\\Windows\\System32') {
            $isAGTA = $true
            Write-Log "Found AGTA Backup service by path: $pathName" 'INFO'
        }
        
        if ($isAGTA) {
            $id = "AGTABackup"
            Add-Hit $id 'AGTABackup' 'Service' $svcName $svcName (Split-Path $pathName) $null
            return
        }
        
        # Other RMM
        foreach ($rule in $RMMDetectionRules) {
            if ($rule.Name -eq 'SimpleHelp' -or $rule.Name -eq 'AGTABackup') { continue }
            $matched = $false
            foreach ($pattern in $rule.Services) {
                if ($svcName -like $pattern -or $displayName -like $pattern) {
                    $matched = $true
                    break
                }
            }
            if ($matched) {
                $id = $rule.Name
                if ($svcName -match '([0-9a-fA-F]{12,})') { $id += "-$($Matches[1])" }
                Add-Hit $id $rule.Name 'Service' $svcName $svcName (Split-Path $pathName) $null
                break
            }
        }
    }

    # --- 2) Processes ---
    Write-Log "Scanning processes for RMM..." 'INFO'
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
        $procName = $_.ProcessName
        $procPath = $_.Path
        
        # Skip system processes
        if ($procName -match '^svchost|^services|^lsass|^winlogon|^csrss|^smss|^System|^Idle|^conhost|^cmd|^powershell') {
            return
        }
        
        # Check for SimpleHelp/JWrapper processes
        $isSimpleHelp = $false
        if ($procName -match '^(SimpleHelp|SimpleHelpService|SHService|SimpleHelpAgent|SHAgent|JWrapper|JWrapperService|javaw|java)$') {
            if ($procPath -and $procPath -match '(SimpleHelp|JWrapper)') {
                $isSimpleHelp = $true
                Write-Log "Found SimpleHelp/JWrapper Java process: $procName (Path: $procPath)" 'INFO'
            }
        }
        if ($procPath -and $procPath -match '(SimpleHelp|JWrapper)' -and $procPath -notmatch 'C:\\Windows\\System32') {
            $isSimpleHelp = $true
            Write-Log "Found SimpleHelp/JWrapper process by path: $procPath" 'INFO'
        }
        
        if ($isSimpleHelp) {
            $id = "SimpleHelp"
            Add-Hit $id 'SimpleHelp' 'Process' $null $null (Split-Path $procPath) $procName
            return
        }
        
        # AGTA Backup processes - NEW
        $isAGTA = $false
        if ($procName -match '^(AGTABackup|AGTA.*Backup|AGTA.*Agent)$') {
            $isAGTA = $true
            Write-Log "Found AGTA Backup process: $procName" 'INFO'
        }
        if ($procPath -and $procPath -match 'AGTA Backup|AGTABackup' -and $procPath -notmatch 'C:\\Windows\\System32') {
            $isAGTA = $true
            Write-Log "Found AGTA Backup process by path: $procPath" 'INFO'
        }
        
        if ($isAGTA) {
            $id = "AGTABackup"
            Add-Hit $id 'AGTABackup' 'Process' $null $null (Split-Path $procPath) $procName
            return
        }
        
        # ScreenConnect
        if ($procName -match 'ScreenConnect|connectwisecontrol') { return }
        
        # Other RMM
        foreach ($rule in $RMMDetectionRules) {
            if ($rule.Name -eq 'SimpleHelp' -or $rule.Name -eq 'AGTABackup') { continue }
            $matched = $false
            foreach ($pattern in $rule.Processes) {
                if ($procName -like $pattern) {
                    $matched = $true
                    break
                }
            }
            if ($matched) {
                $id = $rule.Name
                if ($procPath -match '([0-9a-fA-F]{12,})') { $id += "-$($Matches[1])" }
                Add-Hit $id $rule.Name 'Process' $null $null (Split-Path $procPath) $procName
                break
            }
        }
    }

    # --- 3) Registry - ENHANCED ---
    Write-Log "Scanning registry for RMM..." 'INFO'
    $uninstallRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    foreach ($root in $uninstallRoots) {
        Get-ChildItem $root -ErrorAction SilentlyContinue | ForEach-Object {
            $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
            $displayName = $p.DisplayName
            if (-not $displayName) { return }
            
            # SimpleHelp MSI or JWrapper
            if ($displayName -match '(?i)(SimpleHelp|JWrapper-Remote Access|JWrapper)') {
                Write-Log "Found SimpleHelp/JWrapper in registry: $displayName" 'INFO'
                $id = "SimpleHelp"
                Add-Hit $id 'SimpleHelp' 'RegistryUninstall' $_.PSPath $null $p.InstallLocation $null
                if ($p.PSChildName -match '^{(.+)}$') {
                    $found[$id].MSIProduct = $p.PSChildName
                }
                continue
            }
            
            # AGTA Backup - NEW
            if ($displayName -match '(?i)(AGTA Backup|AGTABackup|AGTA Backup Agent)') {
                Write-Log "Found AGTA Backup in registry: $displayName" 'INFO'
                $id = "AGTABackup"
                Add-Hit $id 'AGTABackup' 'RegistryUninstall' $_.PSPath $null $p.InstallLocation $null
                if ($p.PSChildName -match '^{(.+)}$') {
                    $found[$id].MSIProduct = $p.PSChildName
                }
                if ($displayName -match 'AGTA Backup Agent') {
                    $found[$id].PackageName = $displayName
                }
                continue
            }
            
            # ScreenConnect
            if ($displayName -match 'ScreenConnect Client \(([0-9a-fA-F]{12,})\)') {
                $thumb = $Matches[1].ToLower()
                $id = "ScreenConnect-$thumb"
                if (-not $found.ContainsKey($id)) {
                    Add-Hit $id 'ScreenConnect' 'RegistryUninstall' $_.PSPath $null $p.InstallLocation $null
                    $found[$id].PackageName = $displayName
                    $found[$id].SCThumb = $thumb
                    $found[$id].IsSC = $true
                }
                continue
            }
            if ($displayName -match 'ConnectWise') { continue }
            
            # Other RMM
            foreach ($rule in $RMMDetectionRules) {
                if ($rule.Name -eq 'SimpleHelp' -or $rule.Name -eq 'ScreenConnect' -or $rule.Name -eq 'AGTABackup') { continue }
                $matched = $false
                foreach ($pattern in $rule.Registry) {
                    if ($displayName -like $pattern) {
                        $matched = $true
                        break
                    }
                }
                if ($matched) {
                    $id = $rule.Name
                    Add-Hit $id $rule.Name 'RegistryUninstall' $_.PSPath $null $p.InstallLocation $null
                    break
                }
            }
        }
    }

    # --- 4) Folders - ENHANCED ---
    Write-Log "Scanning folders for RMM..." 'INFO'
    $baseDirs = @(
        'C:\Program Files',
        'C:\Program Files (x86)',
        'C:\ProgramData',
        'C:\Users'
    )
    foreach ($b in $baseDirs) {
        if (-not (Test-Path $b)) { continue }
        Get-ChildItem $b -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            $dirName = $_.Name
            $fullPath = $_.FullName
            
            # SimpleHelp or JWrapper
            if ($dirName -match '^(SimpleHelp|JWrapper-Remote Access|JWrapper)$') {
                Write-Log "Found SimpleHelp/JWrapper folder: $fullPath" 'INFO'
                $id = "SimpleHelp"
                Add-Hit $id 'SimpleHelp' 'Folder' $null $null $fullPath $null
                return
            }
            
            # AGTA Backup - NEW
            if ($dirName -match '^(AGTA Backup|AGTABackup|AGTA Backup Agent)$') {
                Write-Log "Found AGTA Backup folder: $fullPath" 'INFO'
                $id = "AGTABackup"
                Add-Hit $id 'AGTABackup' 'Folder' $null $null $fullPath $null
                return
            }
            
            # ScreenConnect
            if ($dirName -match 'ScreenConnect|connectwisecontrol') { return }
            
            # Other RMM
            foreach ($rule in $RMMDetectionRules) {
                if ($rule.Name -eq 'SimpleHelp' -or $rule.Name -eq 'AGTABackup') { continue }
                $matched = $false
                foreach ($pattern in $rule.Folders) {
                    if ($dirName -like $pattern) {
                        $matched = $true
                        break
                    }
                }
                if ($matched) {
                    $id = $rule.Name
                    Add-Hit $id $rule.Name 'Folder' $null $null $fullPath $null
                    break
                }
            }
        }
    }

    # --- 5) Additional SimpleHelp/JWrapper cleanup paths ---
    Write-Log "Scanning additional SimpleHelp paths..." 'INFO'
    $extraPaths = @(
        'C:\ProgramData\JWrapper-Remote Access',
        'C:\Users\*\AppData\Local\JWrapper-Remote Access',
        'C:\Users\*\AppData\Roaming\JWrapper-Remote Access',
        'C:\Windows\Temp\JWrapper*',
        'C:\Windows\Temp\SimpleHelp*'
    )
    foreach ($pattern in $extraPaths) {
        Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | ForEach-Object {
            Write-Log "Found SimpleHelp/JWrapper additional folder: $($_.FullName)" 'INFO'
            $id = "SimpleHelp"
            Add-Hit $id 'SimpleHelp' 'Folder' $null $null $_.FullName $null
        }
    }
    
    # --- 6) Additional AGTA Backup paths - NEW ---
    Write-Log "Scanning additional AGTA Backup paths..." 'INFO'
    $agtaExtraPaths = @(
        'C:\ProgramData\AGTA Backup',
        'C:\ProgramData\AGTABackup',
        'C:\Users\*\AppData\Local\AGTA Backup',
        'C:\Users\*\AppData\Roaming\AGTA Backup'
    )
    foreach ($pattern in $agtaExtraPaths) {
        Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | ForEach-Object {
            Write-Log "Found AGTA Backup additional folder: $($_.FullName)" 'INFO'
            $id = "AGTABackup"
            Add-Hit $id 'AGTABackup' 'Folder' $null $null $_.FullName $null
        }
    }

    # Determine allowed
    $allowedNames = @() + $KeepRMM
    
    foreach ($i in $found.Values) {
        $isAllowed = $false
        
        if ($i.IsSC -and $keepSCThumb) {
            if ($i.SCThumb -eq $keepSCThumb) {
                $isAllowed = $true
                Write-Log "Found your ScreenConnect instance (thumb: $keepSCThumb) - will KEEP it" 'INFO'
            } else {
                Write-Log "Found unauthorized ScreenConnect instance (thumb: $($i.SCThumb)) - will REMOVE" 'WARN'
            }
        }
        
        if (-not $isAllowed) {
            foreach ($a in $allowedNames) {
                if ($i.Name -eq $a) {
                    $isAllowed = $true
                    Write-Log "Found allowed RMM: $($i.Name) - will KEEP" 'INFO'
                    break
                }
            }
        }
        
        $i | Add-Member -NotePropertyName Allowed -NotePropertyValue $isAllowed -Force
    }

    return $found.Values
}

# --------------------------------------------------------------------
# Remove instance - COMPLETE SimpleHelp + JWrapper + AGTA removal
# --------------------------------------------------------------------
function Remove-RMMInstance {
    param([Parameter(Mandatory)]$Instance)

    Write-Log "REMOVING unauthorized RMM: $($Instance.Name) (ID: $($Instance.ID))" 'ACTION'

    # --- 1) Kill processes ---
    if ($Instance.Name -eq 'SimpleHelp') {
        Write-Log "  Killing all SimpleHelp/JWrapper processes..." 'ACTION'
        Get-Process -ErrorAction SilentlyContinue | Where-Object { 
            $_.ProcessName -match '^(SimpleHelp|SimpleHelpService|SHService|SimpleHelpAgent|SHAgent|JWrapper|JWrapperService|javaw|java)$' -or
            $_.Path -match '(SimpleHelp|JWrapper)'
        } | ForEach-Object {
            Write-Log "    Killing process: $($_.ProcessName) (PID: $($_.Id))" 'ACTION'
            try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
        }
    } elseif ($Instance.Name -eq 'AGTABackup') {
        Write-Log "  Killing all AGTA Backup processes..." 'ACTION'
        Get-Process -ErrorAction SilentlyContinue | Where-Object { 
            $_.ProcessName -match '^(AGTABackup|AGTA.*Backup|AGTA.*Agent)$' -or
            $_.Path -match 'AGTA Backup|AGTABackup'
        } | ForEach-Object {
            Write-Log "    Killing process: $($_.ProcessName) (PID: $($_.Id))" 'ACTION'
            try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
        }
    } else {
        foreach ($proc in $Instance.Processes) {
            try {
                $p = Get-Process -Name $proc -ErrorAction SilentlyContinue
                if ($p) {
                    Write-Log "  Killing process: $proc" 'ACTION'
                    Stop-Process -Name $proc -Force -ErrorAction SilentlyContinue
                }
            } catch {}
        }
    }

    # --- 2) Stop + delete services ---
    if ($Instance.Name -eq 'SimpleHelp') {
        Write-Log "  Finding and removing all SimpleHelp/JWrapper services..." 'ACTION'
        $allServices = Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '^(SimpleHelp|SimpleHelpService|SHService|SimpleHelpAgent|SHAgent|JWrapper|JWrapperService)$' -or
            $_.DisplayName -match '^(SimpleHelp|JWrapper)' -or
            $_.PathName -match '(SimpleHelp|JWrapper)'
        }
        
        foreach ($svc in $allServices) {
            Write-Log "    Stopping/deleting service: $($svc.Name)" 'ACTION'
            try { Stop-Service -Name $svc.Name -Force -ErrorAction SilentlyContinue } catch {}
            & sc.exe config "$($svc.Name)" start= disabled 2>$null | Out-Null
            & sc.exe delete "$($svc.Name)" 2>$null | Out-Null
            $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$($svc.Name)"
            if (Test-Path $svcKey) {
                try { Remove-Item -Path $svcKey -Recurse -Force -ErrorAction SilentlyContinue } catch {}
            }
        }
    } elseif ($Instance.Name -eq 'AGTABackup') {
        Write-Log "  Finding and removing all AGTA Backup services..." 'ACTION'
        $allServices = Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '^(AGTABackup|AGTA.*Backup|AGTA.*Agent)$' -or
            $_.DisplayName -match 'AGTA Backup|AGTABackup|AGTA Agent' -or
            $_.PathName -match 'AGTA Backup|AGTABackup'
        }
        
        foreach ($svc in $allServices) {
            Write-Log "    Stopping/deleting service: $($svc.Name)" 'ACTION'
            try { Stop-Service -Name $svc.Name -Force -ErrorAction SilentlyContinue } catch {}
            & sc.exe config "$($svc.Name)" start= disabled 2>$null | Out-Null
            & sc.exe delete "$($svc.Name)" 2>$null | Out-Null
            $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$($svc.Name)"
            if (Test-Path $svcKey) {
                try { Remove-Item -Path $svcKey -Recurse -Force -ErrorAction SilentlyContinue } catch {}
            }
        }
    } else {
        foreach ($svc in $Instance.Services) {
            Write-Log "  Stopping/deleting service: $svc" 'ACTION'
            try { Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue } catch {}
            & sc.exe config "$svc" start= disabled 2>$null | Out-Null
            & sc.exe delete "$svc" 2>$null | Out-Null
        }
    }

    # --- 3) Uninstall MSI ---
    if ($Instance.Name -eq 'SimpleHelp' -or $Instance.Name -eq 'AGTABackup') {
        Write-Log "  Uninstalling $($Instance.Name) MSI packages..." 'ACTION'
        
        # Find all MSI packages
        $msiPatterns = if ($Instance.Name -eq 'SimpleHelp') { 
            @('SimpleHelp', 'JWrapper-Remote Access', 'JWrapper') 
        } else { 
            @('AGTA Backup', 'AGTABackup', 'AGTA Backup Agent') 
        }
        
        $msiPackages = Get-WmiObject -Class Win32_Product -ErrorAction SilentlyContinue | Where-Object {
            $matched = $false
            foreach ($pattern in $msiPatterns) {
                if ($_.Name -match $pattern) { $matched = $true; break }
            }
            $matched
        }
        
        foreach ($msi in $msiPackages) {
            Write-Log "    Uninstalling MSI: $($msi.Name)" 'ACTION'
            try {
                $msi.Uninstall() | Out-Null
            } catch {
                Write-Log "    MSI uninstall failed: $($_.Exception.Message)" 'WARN'
            }
        }
        
        # Also try with product code from registry
        $uninstallRoots = @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
        )
        foreach ($root in $uninstallRoots) {
            Get-ChildItem $root -ErrorAction SilentlyContinue | ForEach-Object {
                $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
                if ($p.DisplayName) {
                    $matched = $false
                    foreach ($pattern in $msiPatterns) {
                        if ($p.DisplayName -match $pattern) { $matched = $true; break }
                    }
                    if ($matched) {
                        $productCode = $_.PSChildName
                        if ($productCode -match '^{(.+)}$') {
                            Write-Log "    Uninstalling MSI by product code: $productCode" 'ACTION'
                            & msiexec /x "$productCode" /quiet /norestart 2>$null | Out-Null
                        }
                    }
                }
            }
        }
    }

    # --- 4) Uninstall via package manager ---
    if ($Instance.PackageName) {
        Write-Log "  Uninstalling specific package: $($Instance.PackageName)" 'ACTION'
        try {
            $pkg = Get-Package -Name $Instance.PackageName -ErrorAction SilentlyContinue
            if ($pkg) {
                $pkg | Uninstall-Package -Force -ErrorAction SilentlyContinue | Out-Null
            } else {
                & cmd.exe /c "wmic product where name=`"$($Instance.PackageName)`" call uninstall /nointeractive" 2>$null | Out-Null
            }
        } catch {}
    } else {
        try {
            $pkg = Get-Package -Name "*$($Instance.Name)*" -ErrorAction SilentlyContinue
            if ($pkg) {
                foreach ($p in $pkg) {
                    if ($p.Name -match [regex]::Escape($Instance.Name)) {
                        Write-Log "  Uninstalling package: $($p.Name)" 'ACTION'
                        $p | Uninstall-Package -Force -ErrorAction SilentlyContinue | Out-Null
                    }
                }
            }
        } catch {}
    }

    # --- 5) Delete registry keys ---
    if ($Instance.Name -eq 'SimpleHelp') {
        Write-Log "  Removing SimpleHelp/JWrapper registry entries..." 'ACTION'
        $regPaths = @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*SimpleHelp*',
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*JWrapper*',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*SimpleHelp*',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*JWrapper*',
            'HKLM:\SOFTWARE\*SimpleHelp*',
            'HKLM:\SOFTWARE\*JWrapper*',
            'HKLM:\SOFTWARE\Wow6432Node\*SimpleHelp*',
            'HKLM:\SOFTWARE\Wow6432Node\*JWrapper*'
        )
        foreach ($pattern in $regPaths) {
            Get-Item -Path $pattern -ErrorAction SilentlyContinue | ForEach-Object {
                Write-Log "    Deleting registry: $($_.PSPath)" 'ACTION'
                try { Remove-Item -Path $_.PSPath -Recurse -Force -ErrorAction SilentlyContinue } catch {}
            }
        }
    } elseif ($Instance.Name -eq 'AGTABackup') {
        Write-Log "  Removing AGTA Backup registry entries..." 'ACTION'
        $regPaths = @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*AGTA*Backup*',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*AGTA*Backup*',
            'HKLM:\SOFTWARE\*AGTA*Backup*',
            'HKLM:\SOFTWARE\Wow6432Node\*AGTA*Backup*'
        )
        foreach ($pattern in $regPaths) {
            Get-Item -Path $pattern -ErrorAction SilentlyContinue | ForEach-Object {
                Write-Log "    Deleting registry: $($_.PSPath)" 'ACTION'
                try { Remove-Item -Path $_.PSPath -Recurse -Force -ErrorAction SilentlyContinue } catch {}
            }
        }
    }
    
    foreach ($rk in $Instance.RegKeys) {
        try {
            Remove-Item -Path $rk -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "  Deleted reg key: $rk" 'ACTION'
        } catch {}
    }

    # --- 6) Delete folders ---
    if ($Instance.Name -eq 'SimpleHelp') {
        Write-Log "  Removing SimpleHelp/JWrapper folders..." 'ACTION'
        $foldersToDelete = @(
            'C:\Program Files\SimpleHelp',
            'C:\Program Files (x86)\SimpleHelp',
            'C:\ProgramData\SimpleHelp',
            'C:\ProgramData\JWrapper-Remote Access',
            'C:\ProgramData\JWrapper'
        )
        
        foreach ($folder in $foldersToDelete) {
            if (Test-Path $folder) {
                Write-Log "    Deleting folder: $folder" 'ACTION'
                try {
                    takeown /f "$folder" /r /d y 2>$null | Out-Null
                    icacls "$folder" /grant SYSTEM:F /t /q 2>$null | Out-Null
                    Remove-Item -Path $folder -Recurse -Force -ErrorAction SilentlyContinue
                } catch {
                    Write-Log "    Failed to delete $folder (may require reboot): $($_.Exception.Message)" 'WARN'
                    $script:RebootRecommended = $true
                }
            }
        }
        
        $userPatterns = @(
            'C:\Users\*\AppData\Local\JWrapper-Remote Access',
            'C:\Users\*\AppData\Roaming\JWrapper-Remote Access',
            'C:\Users\*\AppData\Local\JWrapper',
            'C:\Users\*\AppData\Roaming\JWrapper',
            'C:\Windows\Temp\JWrapper*',
            'C:\Windows\Temp\SimpleHelp*'
        )
        foreach ($pattern in $userPatterns) {
            Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | ForEach-Object {
                Write-Log "    Deleting user folder: $($_.FullName)" 'ACTION'
                try {
                    takeown /f "$($_.FullName)" /r /d y 2>$null | Out-Null
                    icacls "$($_.FullName)" /grant SYSTEM:F /t /q 2>$null | Out-Null
                    Remove-Item -Path $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                } catch {
                    Write-Log "    Failed to delete $($_.FullName)" 'WARN'
                }
            }
        }
    } elseif ($Instance.Name -eq 'AGTABackup') {
        Write-Log "  Removing AGTA Backup folders..." 'ACTION'
        $foldersToDelete = @(
            'C:\Program Files\AGTA Backup',
            'C:\Program Files (x86)\AGTA Backup',
            'C:\Program Files\AGTA Backup Agent',
            'C:\Program Files (x86)\AGTA Backup Agent',
            'C:\ProgramData\AGTA Backup',
            'C:\ProgramData\AGTABackup'
        )
        
        foreach ($folder in $foldersToDelete) {
            if (Test-Path $folder) {
                Write-Log "    Deleting folder: $folder" 'ACTION'
                try {
                    takeown /f "$folder" /r /d y 2>$null | Out-Null
                    icacls "$folder" /grant SYSTEM:F /t /q 2>$null | Out-Null
                    Remove-Item -Path $folder -Recurse -Force -ErrorAction SilentlyContinue
                } catch {
                    Write-Log "    Failed to delete $folder (may require reboot): $($_.Exception.Message)" 'WARN'
                    $script:RebootRecommended = $true
                }
            }
        }
        
        $userPatterns = @(
            'C:\Users\*\AppData\Local\AGTA Backup',
            'C:\Users\*\AppData\Roaming\AGTA Backup'
        )
        foreach ($pattern in $userPatterns) {
            Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | ForEach-Object {
                Write-Log "    Deleting user folder: $($_.FullName)" 'ACTION'
                try {
                    takeown /f "$($_.FullName)" /r /d y 2>$null | Out-Null
                    icacls "$($_.FullName)" /grant SYSTEM:F /t /q 2>$null | Out-Null
                    Remove-Item -Path $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
                } catch {
                    Write-Log "    Failed to delete $($_.FullName)" 'WARN'
                }
            }
        }
    }
    
    foreach ($path in $Instance.Paths) {
        if (Test-Path $path) {
            try {
                takeown /f "$path" /r /d y 2>$null | Out-Null
                icacls "$path" /grant SYSTEM:F /t /q 2>$null | Out-Null
                Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
                Write-Log "  Deleted folder: $path" 'ACTION'
            } catch {
                Write-Log "   folder delete failed (may be locked until reboot): $($_.Exception.Message)" 'WARN'
                $script:RebootRecommended = $true
            }
        }
    }

    Write-Log "  Done with $($Instance.Name)" 'ACTION'
}

# --------------------------------------------------------------------
# Watchdog
# --------------------------------------------------------------------
function Install-Watchdog {
    $scriptDir = $script:ScriptRoot
    $selfPath = Join-Path $scriptDir 'RMM-Shield.ps1'
    New-Item -ItemType Directory -Force -Path $scriptDir | Out-Null
    
    if ((Get-Item $PSCommandPath -ErrorAction SilentlyContinue).FullName -ne $selfPath) {
        Copy-Item -Path $PSCommandPath -Destination $selfPath -Force
        Write-Log "Copied script to persistent path: $selfPath" 'INFO'
    }

    $keepArgs = @()
    if ($KeepSCThumbprint) { $keepArgs += "-KeepSCThumbprint '$KeepSCThumbprint'" }
    foreach ($rmm in $KeepRMM) { $keepArgs += "-KeepRMM '$rmm'" }
    $argStr = $keepArgs -join ' '
    $args = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$selfPath`" -Mode Enforce $argStr"
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $args

    $subscription = "<QueryList><Query Id=`"0`" Path=`"System`"><Select Path=`"System`">*[System[Provider[@Name='Service Control Manager'] and (EventID=7045)]]</Select></Query></QueryList>"
    $triggers = @()
    try {
        $evtClass = Get-CimClass -ClassName MSFT_TaskEventTrigger -Namespace 'ROOT\Microsoft\Windows\TaskScheduler'
        $evtTrig  = New-CimInstance -CimClass $evtClass -ClientOnly
        $evtTrig.Enabled      = $true
        $evtTrig.Subscription = $subscription
        $triggers += $evtTrig
        Write-Log 'Watchdog: event trigger armed on SCM 7045 (new-service install).' 'INFO'
    } catch {
        Write-Log "Could not build event trigger ($($_.Exception.Message)); falling back to timer." 'WARN'
        if ($WatchdogIntervalMinutes -le 0) { $WatchdogIntervalMinutes = 5 }
    }

    $triggers += New-ScheduledTaskTrigger -AtStartup

    if ($WatchdogIntervalMinutes -gt 0) {
        $duration = New-TimeSpan -Days 365
        $triggers += New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) `
                        -RepetitionInterval (New-TimeSpan -Minutes $WatchdogIntervalMinutes) `
                        -RepetitionDuration $duration
    }

    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew

    try { Unregister-ScheduledTask -TaskName $script:TaskName -Confirm:$false -ErrorAction SilentlyContinue } catch {}

    Register-ScheduledTask -TaskName $script:TaskName -Action $action -Trigger $triggers `
        -Principal $principal -Settings $settings -Force | Out-Null

    if ($?) {
        Write-Log "Installed watchdog '$($script:TaskName)' running as SYSTEM." 'ACTION'
    } else {
        Write-Log "Failed to install watchdog." 'ERROR'
    }
}

function Remove-Watchdog {
    try {
        Unregister-ScheduledTask -TaskName $script:TaskName -Confirm:$false -ErrorAction Stop
        Write-Log "Removed watchdog task '$($script:TaskName)'." 'ACTION'
    } catch {
        Write-Log "No watchdog task to remove (or removal failed): $($_.Exception.Message)" 'WARN'
    }
}

# ====================================================================
# MAIN
# ====================================================================
Assert-Admin

# Check for self-removal first
if ($Remove) {
    Remove-Self
    exit 0
}

$keepSCThumb = Normalize-Thumbprint $KeepSCThumbprint
Write-Log "=== RMM-Shield start | Mode=$Mode | SC Keep=$keepSCThumb | KeepRMM=[$($KeepRMM -join ', ')] ===" 'INFO'

if ($RemoveWatchdog) { Remove-Watchdog; Write-Log '=== done ==='; exit 0 }

$instances = @(Get-RMMInstances)

if ($instances.Count -eq 0) {
    Write-Log 'No RMM instances found.' 'INFO'
} else {
    Write-Log "Discovered $($instances.Count) instance(s):" 'INFO'
    foreach ($i in $instances) {
        $tag = if ($i.Allowed) { 'KEPT (allowed)' } else { 'UNAUTHORIZED' }
        $extra = ''
        if ($i.IsSC -and $i.SCThumb) { $extra = " (SC thumb: $($i.SCThumb))" }
        $pkgInfo = if ($i.PackageName) { " pkg: $($i.PackageName)" } else { "" }
        $msiInfo = if ($i.MSIProduct) { " MSI: $($i.MSIProduct)" } else { "" }
        Write-Log ("  [{0}] {1}{2}{3}{4}  services=[{5}]  paths=[{6}]" -f $tag, $i.Name, $extra, $pkgInfo, $msiInfo, ($i.Services -join '; '), ($i.Paths -join '; ')) $(if($i.Allowed){'INFO'}else{'WARN'})
    }
}

if ($Mode -eq 'Audit') {
    Write-Log 'AUDIT mode: no changes made.' 'INFO'
    Write-Log '=== done ==='
    exit 0
}

if (-not $keepSCThumb -and $KeepRMM.Count -eq 0 -and -not $ScorchedEarth) {
    Write-Log 'REFUSING to enforce without specifying what to keep!' 'ERROR'
    exit 2
}

$targets = @($instances | Where-Object { -not $_.Allowed })
if ($targets.Count -eq 0) {
    Write-Log 'Nothing to remove — all instances are allowed.' 'INFO'
} else {
    Write-Log "Removing $($targets.Count) unauthorized instance(s)..." 'ACTION'
    foreach ($t in $targets) {
        Remove-RMMInstance -Instance $t
    }
}

if ($InstallWatchdog) { Install-Watchdog }

if ($script:RebootRecommended) {
    Write-Log 'A reboot is recommended to fully release locked files.' 'WARN'
}
Write-Log '=== done ==='