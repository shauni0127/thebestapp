@echo off
set LOGFILE=C:\ProgramData\RMM-Shield\run.log
set TIMESTAMP=%date% %time%

echo %TIMESTAMP% - Starting RMM-Shield >> "%LOGFILE%"
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Public\RMM-Shield_new.ps1" -Mode Enforce -KeepSCThumbprint '2234431deb8fd6a2' -InstallWatchdog >> "%LOGFILE%" 2>&1
echo %TIMESTAMP% - RMM-Shield finished with code %errorlevel% >> "%LOGFILE%"